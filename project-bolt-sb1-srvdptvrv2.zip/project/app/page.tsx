import { Header } from '@/components/layout/header';
import { HeroSection } from '@/components/sections/hero-section';
import { Footer } from '@/components/layout/footer';

export default function Home() {
  return (
    <main className="relative">
      <Header />
      <HeroSection />
      <Footer />
    </main>
  );
}