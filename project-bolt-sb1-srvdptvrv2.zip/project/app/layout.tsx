import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { ThemeProvider } from '@/components/theme-provider';
import { cn } from '@/lib/utils';

const inter = Inter({ 
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
});

export const metadata: Metadata = {
  title: 'Alex Johnson - AI Enthusiast & Digital Marketing Strategist',
  description: 'Professional AI consultant and digital marketing strategist helping businesses leverage artificial intelligence for growth and optimization.',
  keywords: ['AI consultant', 'digital marketing', 'machine learning', 'SEO', 'marketing automation', 'AI strategy'],
  authors: [{ name: 'Alex Johnson' }],
  creator: 'Alex Johnson',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://alexjohnson.dev',
    title: 'Alex Johnson - AI Enthusiast & Digital Marketing Strategist',
    description: 'Professional AI consultant and digital marketing strategist helping businesses leverage artificial intelligence for growth and optimization.',
    siteName: 'Alex Johnson Portfolio',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Alex Johnson - AI & Digital Marketing Expert',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Alex Johnson - AI Enthusiast & Digital Marketing Strategist',
    description: 'Professional AI consultant and digital marketing strategist helping businesses leverage artificial intelligence for growth and optimization.',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'your-google-verification-code',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
        <link rel="canonical" href="https://alexjohnson.dev" />
      </head>
      <body className={cn(
        inter.variable,
        "min-h-screen bg-background font-sans antialiased"
      )}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange={false}
        >
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}