import { BlogSection } from '@/components/sections/blog-section';

export const metadata = {
  title: 'Blog - Alex Johnson | AI & Digital Marketing Insights',
  description: 'Latest insights on AI trends, digital marketing strategies, and the future of technology-driven business growth.',
  keywords: ['AI blog', 'digital marketing insights', 'AI trends', 'marketing strategy', 'technology blog'],
};

export default function BlogPage() {
  return (
    <main className="pt-20">
      <BlogSection />
    </main>
  );
}